/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufscar.dc.compiladores.al.sintatico;

import br.ufscar.dc.compiladores.al.sintatico.TabelaDeSimbolos.TipoAl;
import java.util.HashMap;

/**
 *
 * @author vitor
 */
public class AlSemantico extends AlBaseVisitor<Void>{
    
    // inicializar Escopos cria um escopo global
    
    Escopos escopos;
    String errorMessage = " já esta sendo usado no escopo atual";

    
    @Override
    public Void visitPrograma(AlParser.ProgramaContext ctx) {        
        escopos = new Escopos();
        
        visitDeclaracoes(ctx.declaracoes());
        visitCorpo(ctx.corpo());
        return null; 
    }

    @Override
    public Void visitDeclaracao_local(AlParser.Declaracao_localContext ctx) {
        if(ctx.variavel() != null){
            String strTipo = ctx.variavel().tipo().getText();
            TipoAl tipo = AlSemanticoUtils.convertStringToTipoAl(strTipo);
            
            for(var id: ctx.variavel().identificador()){
                for(var ident: id.IDENT()){
                    String nome = ident.getText();
                    if(escopos.existeNaTabelaAtual(nome)){
                        ErrosSemanticos.identificadorExistente(nome, ident.getSymbol().getLine());
                    }else{
                        escopos.inserirNaTabelaAtual(nome, tipo);
                    }
                }
            }
            if (!TabelaDeSimbolos.isTipoBasico(strTipo)) { // VERIFICAR TAMBÉ SE NÃO É UM REGISTRO JA DEFINIDO
                ErrosSemanticos.tipoInexistente(strTipo, ctx.variavel().DOIS_PONTOS().getSymbol().getLine());
            }

        }
        else if(ctx.CONSTANTE() != null){
            String strTipo = ctx.tipo_basico().getText();
            TipoAl tipo = AlSemanticoUtils.convertStringToTipoAl(strTipo);
            String nome = ctx.IDENT().getText();
            if(escopos.existeNaTabelaAtual(nome)){
                ErrosSemanticos.identificadorExistente(nome, ctx.IDENT().getSymbol().getLine());
            }else{
                escopos.inserirNaTabelaAtual(nome, tipo);
            }
        }
        else{
            String nome = ctx.IDENT().getText();
            
            TipoAl tipo = AlSemanticoUtils.verificarTipoDeTipoContext(ctx.tipo());
            if(escopos.existeNaTabelaAtual(nome)){
                ErrosSemanticos.identificadorExistente(nome, ctx.IDENT().getSymbol().getLine());
            }else{
                escopos.inserirNaTabelaAtual(nome, tipo);
            }
          
        }
        return null;
    }

    @Override
    public Void visitDeclaracao_global(AlParser.Declaracao_globalContext ctx) {
        // procedimentos não retornam dados, isso é, basta verificar se o nome esta disponível
        if(ctx.PROCEDIMENTO() != null){
            String nome = ctx.IDENT().getText();
            
            //verifica se já existe alguma declaração com esse nome no escopo atual
            if(escopos.existeNaTabelaAtual(nome)){
                ErrosSemanticos.identificadorExistente(nome, ctx.IDENT().getSymbol().getLine());
            }
            else{
                escopos.inserirNaTabelaAtual(nome, TipoAl.PROCEDIMENTO);

                // se houver parâmetros precisamos salvar os tipos deles
                if(ctx.parametros() != null){
                    for(var p: ctx.parametros().parametro()){
                        String tipo = p.tipo_estendido().getText();
                        for(var id: p.identificador()){
                            if(AlSemanticoUtils.identificadorExiste(escopos, id)){
                                // não precisa adicionar erro semantico por que a função identificador existe já adiciona
                            }
                        }
                    }
                }
            }
        }
        else{
            
        }
         
        
        return null;
    }
    
    @Override
    public Void visitCorpo(AlParser.CorpoContext ctx) {
        for (var decLocal: ctx.declaracao_local()) {
            visitDeclaracao_local(decLocal);
        }
        
        for (var cmd: ctx.cmd()) {
            visitCmd(cmd);
        } 
        return null;
    }

    @Override
    public Void visitRegistro(AlParser.RegistroContext ctx) {
        HashMap<String, TipoAl> atributos = new HashMap<>();
        for(var v: ctx.variavel()){
            TipoAl tipo = AlSemanticoUtils.verificarTipoDeTipoContext(v.tipo());
            for(var id: v.identificador()){
                String nome = id.ident1.getText();
                // temos o nome e o tipo, vamos adicionar esse atributo ao hashmap
                atributos.put(nome, tipo);
            }
            
        }
        // escopos.inserirNaTabelaAtual(nome, tipo, tipo, parametros, atributos);
        return null;
    }

    @Override
    public Void visitExp_aritmetica(AlParser.Exp_aritmeticaContext ctx) {
        AlSemanticoUtils.verificarTipo(escopos, ctx);
        return super.visitExp_aritmetica(ctx);
    }  

    @Override
    public Void visitCmd_chamada(AlParser.Cmd_chamadaContext ctx) {
        String nome = ctx.IDENT().getText();
        if(escopos.existe(nome)){
            // é procedimento ou função ?
            if(escopos.verificar(nome) == TipoAl.PROCEDIMENTO){
                //parametros
                
            }
            else{
                // parametros e retorno
            }
        }
        else{
            AlSemanticoUtils.adicionarErroSemantico(ctx.IDENT().getSymbol(), "procedimento ou função não declarado");
        }
        return null;
    }
    
    @Override
    public Void visitCmd_atribuicao(AlParser.Cmd_atribuicaoContext ctx) {
        TabelaDeSimbolos.TipoAl tipoLadoEsquerdo = null;
        TabelaDeSimbolos.TipoAl tipoLadoDireito;
        String nome = "";
        if(escopos.existe(ctx.identificador().getText())) {
            for(var ident: ctx.identificador().IDENT()){
                nome = ident.getText();
                if (!escopos.existe(nome)){
                    ErrosSemanticos.identificadorInexistente(nome, ident.getSymbol().getLine());
                    return null;
                } else {
                    tipoLadoEsquerdo = escopos.verificar(nome);
                }
                
            }   
        }
        
        tipoLadoDireito = AlSemanticoUtils.verificarTipo(escopos, ctx.expressao());
        
        if(tipoLadoDireito != tipoLadoEsquerdo ) {
            if (tipoLadoEsquerdo == TabelaDeSimbolos.TipoAl.REAL && 
                    tipoLadoDireito == TabelaDeSimbolos.TipoAl.INTEIRO) {
            } else {
                // System.out.println("Esquerdo: " + tipoLadoEsquerdo + " Direito: " + tipoLadoDireito);
                ErrosSemanticos.atribuicaoIncompativel(nome, ctx.expressao().start.getLine());
            } 
        }
        return null;
    }
    
    @Override
    public Void visitCmd_leia(AlParser.Cmd_leiaContext ctx) {
        for (var identificador: ctx.identificador()) {
            for (var IDENT: identificador.IDENT()) {
                if(!escopos.existe(IDENT.getText())) {
                    ErrosSemanticos.identificadorInexistente(IDENT.getText(), IDENT.getSymbol().getLine());
                }
            }
        }  
        return null;
    }

    @Override
    public Void visitCmd_escreva(AlParser.Cmd_escrevaContext ctx) {
        for (var ex: ctx.expressao()) {
            AlSemanticoUtils.verificarTipo(escopos, ex);
        }
        return null;
    }

    @Override
    public Void visitCmd_se(AlParser.Cmd_seContext ctx) {
        AlSemanticoUtils.verificarTipo(escopos, ctx.expressao());
        for (var cmd : ctx.cmd()) {
            visitCmd(cmd);
        }
        return null;
    }

    @Override
    public Void visitCmd_caso(AlParser.Cmd_casoContext ctx) {
        TabelaDeSimbolos.TipoAl tipoExpAritmetica = AlSemanticoUtils.verificarTipo(escopos, ctx.exp_aritmetica());
        if(tipoExpAritmetica != TabelaDeSimbolos.TipoAl.INTEIRO) {
            ErrosSemanticos.atribuicaoIncompativel(ctx.exp_aritmetica().getText(), ctx.getStart().getLine());
        }
        for (var ItemSelecao: ctx.selecao().item_selecao()){
            for (var cmd : ItemSelecao.cmd()) {
                visitCmd(cmd);
            }
        }
        if(ctx.cmd() != null ) {
            visitCmd(ctx.cmd());
        }
        return null;
    }

    @Override
    public Void visitCmd_para(AlParser.Cmd_paraContext ctx) {
        if(!escopos.existe(ctx.IDENT().getText())){
            ErrosSemanticos.identificadorInexistente(ctx.IDENT().getText(), ctx.getStart().getLine());
        }
        for (var exp_aritmetica : ctx.exp_aritmetica()) {
            if(AlSemanticoUtils.verificarTipo(escopos, exp_aritmetica) != TabelaDeSimbolos.TipoAl.INTEIRO) {
                ErrosSemanticos.atribuicaoIncompativel(ctx.IDENT().getText(), ctx.getStart().getLine());
            }
        }
        
        for(var cmd : ctx.cmd()) {
            visitCmd(cmd);
        }
        return null;
    }

    @Override
    public Void visitCmd_enquanto(AlParser.Cmd_enquantoContext ctx) {
        AlSemanticoUtils.verificarTipo(escopos, ctx.expressao());
        
        for(var cmd : ctx.cmd()) {
            visitCmd(cmd);
        }
        return null;
    }

    @Override
    public Void visitCmd_faca(AlParser.Cmd_facaContext ctx) {
        for(var cmd : ctx.cmd()) {
            visitCmd(cmd);
        }
        
        AlSemanticoUtils.verificarTipo(escopos, ctx.expressao());
        return null;
    }
    
    
}
